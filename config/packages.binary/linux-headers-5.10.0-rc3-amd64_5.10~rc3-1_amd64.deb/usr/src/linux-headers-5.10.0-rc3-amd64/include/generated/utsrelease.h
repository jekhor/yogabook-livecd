#define UTS_RELEASE "5.10.0-rc3-amd64"
